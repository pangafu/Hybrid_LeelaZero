def main():
    w1 = open('oldWeight1.txt', 'rt')
    w2 = open('oldWeight2.txt', 'rt')
    #w3 = open('oldWeight3.txt', 'rt')
    #w4 = open('oldWeight4.txt', 'rt')
    weight = open('newWeight.txt', 'wt')
    r1 = 1; r2 = 1
    #r3 = 1; r4 = 1

    n = 0
    while n<67:
        v1 = [float(x) for x in w1.readline().split()]
        v2 = [float(x) for x in w2.readline().split()]
        #v3 = [float(x) for x in w3.readline().split()]
        #v4 = [float(x) for x in w4.readline().split()]
        if n==0: weight.write('1')
        else:
            weight.write('\n')
            for i,x in enumerate(v1):
                weight.write('%g ' % ((x*r1+v2[i]*r2)/(r1+r2)))
                #weight.write('%g ' % ((x*r1+v2[i]*r2+v3[i]*r3)/(r1+r2+r3)))
                #weight.write('%g ' % ((x*r1+v2[i]*r2+v3[i]*r3+v4[i]*r4)/(r1+r2+r3+r4)))
        n += 1
    print('Finished.')
    weight.close()

if __name__ == '__main__': main()